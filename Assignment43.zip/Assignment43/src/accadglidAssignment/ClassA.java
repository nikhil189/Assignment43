package accadglidAssignment;

import java.io.IOException;

public class ClassA extends ClassB{
	
	@Override
	public void test()
	{
		System.out.println("test method in class A");
	}
	public static void main(String ...K)throws IOException
	{
		ClassA obj = new ClassA();
		obj.testimplementation();
		
	}
	public void testimplementation()
	{
		test();
	}
}
