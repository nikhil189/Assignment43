package accadglidAssignment;

public class ClassB extends ClassC{
	
	@Override
	public void test()
	{
		System.out.println("test method in class B");
	}

}
