package accadglidAssignment;

public class ClassC {

	public void test()
	{
		System.out.println("test method in class c ");
	}
}
